import React, { useState } from "react";
import SearchBox from "./components/SearchBox/SearchBox";
import axios from "axios";
import List from "./components/List/List";
import Error from "./components/Error/Error";

function App() {
  const [dataRetrieved, setDataRetrieved] = useState([]);
  const [error, setError] = useState(false);

  const onSubmit = (inputEntered) => {
    if (inputEntered) {
      axios
        .get(`https://help-search-api-prod.herokuapp.com/search`, {
          params: {
            query: inputEntered,
          },
        })
        .then((data) => {
          console.log(data.data.results);
          setDataRetrieved(data.data.results);
        })
        .catch((error) => {
          setError(true);
        });
    }
  };
  if (!error) {
    return (
      <div>
        <SearchBox onSubmit={onSubmit} />
        <List dataRetrieved={dataRetrieved} />
      </div>
    );
  }
  return <Error />;
}

export default App;
