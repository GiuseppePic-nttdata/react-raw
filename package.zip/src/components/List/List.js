import React, { useState } from "react";

const List = ({ dataRetrieved }) => {
  const ROWS_PAGINATION = 10;
  const [rowsToShow, setRowsToShow] = useState(ROWS_PAGINATION);

  const incrementRowsToShow = (rows) => {
    setRowsToShow(rowsToShow + rows);
  };

  const onClickButton = (e) => {
    e.preventDefault();
    incrementRowsToShow(ROWS_PAGINATION);
  };

  const getRows = (dataToFormat) => {
    const subData = dataToFormat.slice(0, rowsToShow);

    return subData.map((data) => (
      <tr key={data.title}>
        <td>{data.title}</td>
        <td>{data.description}</td>
      </tr>
    ));
  };

  if (dataRetrieved && dataRetrieved.length) {
    return (
      <div>
        <table>
          <tbody>{getRows(dataRetrieved)}</tbody>
        </table>
        <button onClick={onClickButton}>Show other items</button>
      </div>
    );
  }
  return <></>;
};

export default List;
