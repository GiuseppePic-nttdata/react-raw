import React, { useRef } from "react";

const SearchBox = ({ onSubmit }) => {
  const onFormSubmit = (e) => {
    e.preventDefault();
    if (inputRef.current.value) {
      onSubmit(inputRef.current.value);
    }
  };

  const onKeyUp = (e) => {
    e.preventDefault();
    if (inputRef.current.value && e.key === "Enter") {
      onSubmit(inputRef.current.value);
    }
  };

  const inputRef = useRef(null);

  return (
    <form onSubmit={onFormSubmit} onKeyUp={onKeyUp}>
      <input ref={inputRef} type="text" />
      <button type="submit">Execute query</button>
    </form>
  );
};

export default SearchBox;
