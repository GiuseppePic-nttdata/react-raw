import React from "react";

const Error = () => {
  return <div>Something happened</div>;
};

export default Error;
